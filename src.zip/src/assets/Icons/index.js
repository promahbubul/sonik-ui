import { FaPhoneAlt } from "react-icons/fa";
import { HiOutlineMail } from "react-icons/hi";
import { RiUserReceived2Line } from "react-icons/ri";
import { IoIosArrowBack } from "react-icons/io";


// const dhakaIcon = "Dhaka";

export { FaPhoneAlt, HiOutlineMail, RiUserReceived2Line, IoIosArrowBack };
