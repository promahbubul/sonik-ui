const siteMenu = [
  { id: 1, title: "Home", href: "/" },
  { id: 2, title: "Programs", href: "/" },
  { id: 3, title: "About Us", href: "/" },
  { id: 4, title: "Store", href: "/" },
];

const infoMenu = [
  { id: 1, title: "FAQ", href: "/" },
  { id: 2, title: "Site Map", href: "/" },
  { id: 3, title: "Cookies Policy", href: "/" },
  { id: 4, title: "Contact Us", href: "/" },
];

export { siteMenu, infoMenu };
