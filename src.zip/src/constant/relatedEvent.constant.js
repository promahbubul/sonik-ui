const relatedEventData = [
  {
    id: 1,
    img: "/assets/event/event.png",
    name: "Lost Boys x Yoyaku",
    data: "Thu, Jun 15",
    author: "Forte Antenne",
  },
  {
    id: 2,
    img: "/assets/event/event.png",
    name: "Lost Boys x Yoyaku",
    data: "Thu, Jun 15",
    author: "Forte Antenne",
  },
  {
    id: 3,
    img: "/assets/event/event.png",
    name: "Lost Boys x Yoyaku",
    data: "Thu, Jun 15",
    author: "Forte Antenne",
  },
  {
    id: 4,
    img: "/assets/event/event.png",
    name: "Lost Boys x Yoyaku",
    data: "Thu, Jun 15",
    author: "Forte Antenne",
  },
];

export default relatedEventData;
