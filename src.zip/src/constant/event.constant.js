const eventData = [
  { id: 1, img: "/assets/event/avatar-1.png", name: "Adam Port" },
  { id: 2, img: "/assets/event/avatar-2.png", name: "CARLITA" },
  { id: 3, img: "/assets/event/avatar-3.png", name: "MAZ" },
];

export default eventData;
